<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

include 'conexao.php';

$idUsuario = $_SESSION['usuario_id'];

$nome = $_POST['nome'];
$bio = $_POST['bio'];

if (!empty($_FILES['foto']['name'])) {

    $foto = uniqid() . "_" . basename($_FILES['foto']['name']);

    move_uploaded_file(
        $_FILES['foto']['tmp_name'],
        "uploads/" . $foto
    );

    $sql = "
        UPDATE usuarios
        SET nome = ?, bio = ?, foto = ?
        WHERE id = ?
    ";

    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("sssi", $nome, $bio, $foto, $idUsuario);

} else {

    $sql = "
        UPDATE usuarios
        SET nome = ?, bio = ?
        WHERE id = ?
    ";

    $stmt = $conexao->prepare($sql);
    $stmt->bind_param("ssi", $nome, $bio, $idUsuario);
}

$stmt->execute();

header("Location: index.php");
exit;