<?php


session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

include 'conexao.php';

$idUsuario = $_SESSION['usuario_id'];

$stmt = $conexao->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->bind_param("i", $idUsuario);
$stmt->execute();

$perfil = $stmt->get_result()->fetch_assoc();

?>

<!DOCTYPE html>
<html>
<head>
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="editar_css.css">
</head>
<body>

<div class="editar-card">

    <h1>Editar Perfil</h1>

  <div class="preview-container">

<?php if (!empty($perfil['foto'])): ?>

    <img
        src="uploads/<?= htmlspecialchars($perfil['foto']); ?>"
        class="preview-foto"
        alt="Foto de Perfil">

<?php else: ?>

    <img
    src="uploads/<?= htmlspecialchars($perfil['foto'] ?? 'perfil_padrao.jpg'); ?>"
    class="preview-foto"
    alt="Foto de Perfil">
        alt="Foto de Perfil">

<?php endif; ?>

</div>

    <form action="salvar_perfil.php" method="POST" enctype="multipart/form-data">

        <label>Nome</label>

        <input
            type="text"
            name="nome"
           value="<?= htmlspecialchars($perfil['nome'] ?? ''); ?>"
            required>

        <label>Bio</label>

        <textarea name="bio"><?= htmlspecialchars($perfil['bio'] ?? ''); ?></textarea>

        <label>Foto de Perfil</label>

        <input
            type="file"
            name="foto"
            accept="image/*">

        <div class="botoes">

            <button type="submit" class="btn-salvar">
                Salvar Alterações
            </button>

            <a href="index.php" class="btn-voltar">
                Voltar
            </a>

        </div>

    </form>

</div>